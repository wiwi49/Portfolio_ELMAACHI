import networkx as nx
import matplotlib.pyplot as plt
from louvain import louvain
from fichier_operations import read_file, write
from graph_operations import graphe_personnages, print_graph

if __name__ == "__main__":      
    # étape 1 : Lire les données 
    personnages = read_file("data/personnagesMIS.txt")
    relations = read_file("data/relationsMIS.txt")
    print("étape 1 : ok")

    # étape 2 : Construire le graphe
    graph = graphe_personnages(personnages, relations)
    print("étape 2 ok")

    # étape 3 : recherche de communauté par l'algorithme de Louvain
    communautes = louvain(graph)
    write("data/communautes.txt", communautes)

    print_graph(graph)

    # Convertir le dictionnaire en un objet Graph de NetworkX
    G = nx.Graph({node: {v: weight for v, weight in neighbors} for node, neighbors in graph.items()})

    # Utiliser l'algorithme de disposition spring_layout avec une valeur spécifique de k
    k_value = 5
    pos = nx.spring_layout(G, k=k_value)

    # Ajuster les positions des nœuds en fonction de leur communauté
    for node, community in communautes.items():
        pos[node][0] += community * 0.1  # Ajustement horizontal basé sur la communauté
        pos[node][1] += community * 1.0  # Ajustement vertical basé sur la communauté

    # Définir les couleurs pour chaque nœud en fonction de sa communauté
    node_colors = [communautes[node] for node in G.nodes()]

    # Visualiser le graphe avec des couleurs de communauté
    nx.draw(G, pos, with_labels=True, font_weight='bold', node_size=700, node_color=node_colors, cmap=plt.cm.Set1, edge_color='gray')
    plt.show()
