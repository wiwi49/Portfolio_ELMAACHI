from itertools import combinations
import networkx as nx
import matplotlib.pyplot as plt
from itertools import combinations
import random

def louvain(graph):
    # la fonction louvain
    def initialize_communities(graph):
        return {node: i for i, node in enumerate(graph)}

    def neighbors(node, graph):
        return [neighbor for neighbor, _ in graph[node]]

    def move_node(node, neighbor, communities):
        new_communities = communities.copy()
        new_communities[node] = new_communities[neighbor]
        return new_communities

    def calculate_modularity(graph, communities):
        modularity = 0
        total_edges = sum(sum(weight for _, weight in neighbors) for neighbors in graph.values()) // 2

        for pair_communities in combinations(set(communities.values()), 2):
            fraction_intra_community = calculate_fraction_intra_community(graph, pair_communities, communities, total_edges)
            modularity += fraction_intra_community - ((calculate_weighted_edges_in_community(graph, pair_communities[0], communities) / total_edges) ** 2)

        return modularity
    
    #Ici j'ai rajouter le fonction display modularity_evolytion
    def display_modularity_evolution(graph, communities):
        modularity_evolution = []
        initial_modularity = calculate_modularity(graph, communities)
        modularity_evolution.append(initial_modularity)
 
        while True:
            for node in graph:
                for neighbor in neighbors(node, graph):
                    new_communities = move_node(node, neighbor, communities)
                    current_modularity = calculate_modularity(graph, new_communities)
 
                    if current_modularity > modularity_evolution[-1]:
                        modularity_evolution.append(current_modularity)
                        communities = new_communities
 
            if modularity_evolution[-1] == calculate_modularity(graph, communities):
                break
 
        print("Modularity Evolution:")
        for i, modularity in enumerate(modularity_evolution):
            print(f"Iteration {i + 1}: Modularity = {modularity}")
            
    def calculate_fraction_intra_community(graph, pair_communities, communities, total_edges):
        edges_intra_community = calculate_weighted_edges_between_communities(graph, pair_communities, communities)
        edges_total = calculate_weighted_edges_within_community(graph, pair_communities[0], communities)
        return edges_intra_community / edges_total if edges_total != 0 else 0

    def calculate_weighted_edges_between_communities(graph, pair_communities, communities):
        return sum(weight for node in graph for neighbor, weight in graph[node]
                   if communities[node] == pair_communities[0] and communities[neighbor] == pair_communities[1])

    def calculate_weighted_edges_within_community(graph, community, communities):
        return sum(weight for node in graph for neighbor, weight in graph[node]
                   if communities[node] == community and communities[neighbor] == community)

    def calculate_weighted_edges_in_community(graph, community, communities):
        return sum(weight for node in graph for neighbor, weight in graph[node]
                   if communities[node] == community)

    # Initialisation : chaque nœud est sa propre communauté
    communities = initialize_communities(graph)
    best_modularity = calculate_modularity(graph, communities)

    while True:
        for node in graph:
            for neighbor in neighbors(node, graph):
                new_communities = move_node(node, neighbor, communities)
                current_modularity = calculate_modularity(graph, new_communities)

                if current_modularity > best_modularity:
                    best_modularity = current_modularity
                    communities = new_communities

        # Si la modularité n'évolue plus, terminer
        if best_modularity == calculate_modularity(graph, communities):
            break

    return communities
